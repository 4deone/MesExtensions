package cm.deone.mesextensions;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import cm.deone.mesextensions.models.Agent;
import cm.deone.mesextensions.models.FirebaseDatabaseHelper;

public class NewAgentActivity extends AppCompatActivity {

    private EditText mLogin;
    private EditText mDomain;
    private EditText mExtension;
    private EditText mNom;
    private EditText mPassword;
    private EditText mWeb;
    private Spinner mspCampagne;

    private Button mAdd_btn;
    private Button mBack_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_agent);
        mLogin = (EditText)findViewById(R.id.tvLogin);
        mDomain = (EditText)findViewById(R.id.tvDomain);
        mExtension = (EditText)findViewById(R.id.tvExtension);
        mNom = (EditText)findViewById(R.id.tvNomAgent);
        mPassword = (EditText)findViewById(R.id.tvPassword);
        mWeb = (EditText)findViewById(R.id.tvWeb);
        mspCampagne = (Spinner) findViewById(R.id.spCampagne);
        mAdd_btn = (Button) findViewById(R.id.add_btn);
        mBack_btn = (Button)findViewById(R.id.back_btn);

        mAdd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Agent agent = new Agent();
                agent.setLogin(mLogin.getText().toString());
                agent.setDomain(mDomain.getText().toString());
                agent.setExtension(Long.parseLong(mExtension.getText().toString()));
                agent.setNom(mNom.getText().toString());
                agent.setPassword(mPassword.getText().toString());
                agent.setWeb(mWeb.getText().toString());
                agent.setCampagne(mspCampagne.getSelectedItem().toString());
                new FirebaseDatabaseHelper().addAgent(agent, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoader(List<Agent> agents, List<String> keys) {

                    }

                    @Override
                    public void DataIsInsered() {
                        Toast.makeText(NewAgentActivity.this, "The agent record has " +
                                "been inserted successfully", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); return;
            }
        });
    }
}
