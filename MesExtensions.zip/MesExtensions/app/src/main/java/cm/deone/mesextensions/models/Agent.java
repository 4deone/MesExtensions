package cm.deone.mesextensions.models;

public class Agent {

    private String campagne;
    private String domain;
    private long extension;
    private String login;
    private String nom;
    private String password;
    private String web;

    public Agent() {
    }

    public Agent(String login, String password, String domain, long extension, String nom, String campagne, String web) {
        this.login = login;
        this.password = password;
        this.domain = domain;
        this.extension = extension;
        this.nom = nom;
        this.campagne = campagne;
        this.web = web;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public long getExtension() {
        return extension;
    }

    public void setExtension(long extension) {
        this.extension = extension;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String name) {
        this.nom = name;
    }

    public String getCampagne() {
        return campagne;
    }

    public void setCampagne(String campagne) {
        this.campagne = campagne;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }
}
