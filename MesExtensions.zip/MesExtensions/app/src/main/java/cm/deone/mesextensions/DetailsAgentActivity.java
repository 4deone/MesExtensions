package cm.deone.mesextensions;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.List;

import cm.deone.mesextensions.models.Agent;
import cm.deone.mesextensions.models.FirebaseDatabaseHelper;

public class DetailsAgentActivity extends AppCompatActivity {

    private EditText mLogin;
    private EditText mDomain;
    private EditText mExtension;
    private EditText mNom;
    private EditText mPassword;
    private EditText mWeb;
    private Spinner mspCampagne;

    private Button mUpdate_btn;
    private Button mDelete_btn;
    private Button mBack_btn;

    private String key;
    private String campagne;
    private String domain;
    private long extension;
    private String login;
    private String nom;
    private String password;
    private String web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_agent);

        key = getIntent().getStringExtra("key");
        campagne = getIntent().getStringExtra("campagne");
        domain = getIntent().getStringExtra("domain");
        extension = getIntent().getLongExtra("extension", 0);
        login = getIntent().getStringExtra("login");
        nom = getIntent().getStringExtra("nom");
        password = getIntent().getStringExtra("password");
        web = getIntent().getStringExtra("web");

        mLogin = (EditText)findViewById(R.id.tvLogin);
        mLogin.setText(login);
        mDomain = (EditText)findViewById(R.id.tvDomain);
        mDomain.setText(domain);
        mExtension = (EditText)findViewById(R.id.tvExtension);
        mExtension.setText("" + extension);
        mNom = (EditText)findViewById(R.id.tvNomAgent);
        mNom.setText(nom);
        mPassword = (EditText)findViewById(R.id.tvPassword);
        mPassword.setText(password);
        mWeb = (EditText)findViewById(R.id.tvWeb);
        mWeb.setText(web);
        mspCampagne = (Spinner) findViewById(R.id.spCampagne);
        mspCampagne.setSelection(getIndex_SpinnerItem(mspCampagne, campagne));

        mUpdate_btn = (Button) findViewById(R.id.update_btn);
        mDelete_btn = (Button)findViewById(R.id.delete_btn);
        mBack_btn = (Button)findViewById(R.id.back_btn);

        mUpdate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Agent agent = new Agent();
                agent.setLogin(mLogin.getText().toString());
                agent.setDomain(mDomain.getText().toString());
                agent.setExtension(Long.parseLong(mExtension.getText().toString()));
                agent.setNom(mNom.getText().toString());
                agent.setPassword(mPassword.getText().toString());
                agent.setWeb(mWeb.getText().toString());
                agent.setCampagne(mspCampagne.getSelectedItem().toString());

                new FirebaseDatabaseHelper().updateAgent(key, agent, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoader(List<Agent> agents, List<String> keys) {

                    }

                    @Override
                    public void DataIsInsered() {

                    }

                    @Override
                    public void DataIsUpdated() {
                        Toast.makeText(DetailsAgentActivity.this, "The agent record has " +
                                "been updated successfully", Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void DataIsDeleted() {

                    }
                });
            }
        });

        mDelete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new FirebaseDatabaseHelper().deleteAgent(key, new FirebaseDatabaseHelper.DataStatus() {
                    @Override
                    public void DataIsLoader(List<Agent> agents, List<String> keys) {

                    }

                    @Override
                    public void DataIsInsered() {

                    }

                    @Override
                    public void DataIsUpdated() {

                    }

                    @Override
                    public void DataIsDeleted() {
                        Toast.makeText(DetailsAgentActivity.this, "The agent record has " +
                                "been deleted successfully", Toast.LENGTH_LONG).show();
                        finish(); return;
                    }
                });
            }
        });

        mBack_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); return;
            }
        });
    }

    private int getIndex_SpinnerItem(Spinner spinner, String item){
        int index = 0;
        for(int i = 0; i < spinner.getCount(); i++){
            if (spinner.getItemAtPosition(i).equals(item)){
                index = i;
                break;
            }
        }
        return index;
    }
}
