package cm.deone.mesextensions;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cm.deone.mesextensions.models.Agent;
import cm.deone.mesextensions.models.FirebaseDatabaseHelper;
import cm.deone.mesextensions.models.RecyclerView_Config;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecylerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecylerView = (RecyclerView)findViewById(R.id.recycler_agents);
        new FirebaseDatabaseHelper().readAgents(new FirebaseDatabaseHelper.DataStatus() {
            @Override
            public void DataIsLoader(List<Agent> agents, List<String> keys) {
                findViewById(R.id.loading_agent_pb).setVisibility(View.GONE);
                new RecyclerView_Config().setConfig(mRecylerView, MainActivity.this, agents, keys);
            }

            @Override
            public void DataIsInsered() {

            }

            @Override
            public void DataIsUpdated() {

            }

            @Override
            public void DataIsDeleted() {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.agentlist_activity_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.new_agent:
                startActivity(new Intent(this, NewAgentActivity.class));
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
